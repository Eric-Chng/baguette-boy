import java.awt.Rectangle;

public interface Damagable {

	Rectangle getRect();
	void takeDamage(int damage);
}
