
public class Potion extends Item{

	private int amt;
	
	public Potion(int x, int y, int healAmt) {
		super("hp", x, y);
		amt = healAmt;
	}
	
	public int getHeal() {
		return amt;
	}

}
