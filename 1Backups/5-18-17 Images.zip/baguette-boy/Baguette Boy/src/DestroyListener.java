
public interface DestroyListener {

	void destroy(Object a);
}
